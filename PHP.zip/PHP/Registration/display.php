<?php
// display.php
if (!isset($_SESSION['guest_id'])) {
    $_SESSION['guest_id'] = uniqid();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? 'N/A';
    $description = $_POST['description'] ?? 'N/A';
    $price = $_POST['price'] ?? 'N/A';
    $discount = $_POST['discountPercentage'] ?? 'N/A';
    $rating = $_POST['rating'] ?? 'N/A';
    $sku = $_POST['sku'] ?? 'N/A';
    $stockStatus = $_POST['stockStatus'] ?? 'N/A';
    $shippingInfo = $_POST['shippingInfo'] ?? 'N/A';
    $warrantyInfo = $_POST['warrantyInfo'] ?? 'N/A';
    $returnPolicy = $_POST['returnPolicy'] ?? 'N/A';
    //$qrCode = $_POST['qrCode'] ?? 'N/A';
} else {
    echo "Invalid access.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Submitted Product Details</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="card w-96 bg-base-100 shadow-xl m-4">
        <div class="card-body">
            <h2 class="card-title"><?= $title?></h2>
           
            <p><strong>Price:</strong> $<?= $price?></p>
            <p><strong>Discount:</strong> <?= $discount?>%</p>
            <p><strong>Rating:</strong> <?= $rating?></p>
            <p><strong>SKU:</strong> <?= $sku?></p>
            <p><strong>Stock Status:</strong> <?= $stockStatus?></p>
             <p><strong>Description:</strong> <?= $description?></p>
            <!-- <p><strong>Shipping Info:</strong> <?// $shippingInfo?></p>
            <p><strong>Warranty:</strong> <?//$warrantyInfo?></p>
            <p><strong>Return Policy:</strong> <?// $returnPolicy?></p> -->
            <!-- <p><strong>QR Code:</strong> <?// $qrCode?></p>
            <img src="<?//$qrCode ?>" alt="Product QR Code" style="width:300px;height: 300px";/> -->
             <a href="<?= "posts.php" ?>">
                        <button class="btn btn-primary">Home</button>
                    </a>  
        </div>
    </div>
</body>
</html>
 