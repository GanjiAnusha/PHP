<?php
include("session.php");

if (!isset($_SESSION['guest_id'])) {
    $_SESSION['guest_id'] = uniqid();
}

$productId = $_GET['pid'];
$ch = curl_init("https://dummyjson.com/products/{$productId}");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$product = json_decode($response, true);

if (!$product) {
    echo "Product not found.";
    exit;
}
?>
