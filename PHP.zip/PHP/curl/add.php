<?php
include("session.php");
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json']
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);

        if (!empty($data['accessToken'])) {
            $_SESSION['accessToken'] = $data['accessToken'];
            $_SESSION['user'] = $data;
            header("Location: posts.php");
            exit;
        } else {
            $error = "Invalid credentials. Please try again.";
        }
    } else {
        $error = "Please enter both username and password.";
    }
} elseif (isset($_POST['title'])) {
    // Add product
    $newProduct = [
        'title' => $_POST['title'],
        'price' => $_POST['price'],
        'discountPercentage' => $_POST['discountPercentage'],
        'description' => $_POST['description'],
        'rating' => $_POST['rating']
    ];

    $ch = curl_init('https://dummyjson.com/products/add');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => json_encode($newProduct),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $addedProduct = json_decode($response, true);
    $_SESSION['custom_products'][] = $addedProduct;

    header("Location: posts.php");
    exit;
}
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        body {
            min-height: 100vh;
            background-color: #f3f4f6;
            /* Tailwind's gray-100 */
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }

        .card {
            width: 24rem;
            /* 96 */
        }
    </style>
</head>

<body>
    <div class="card bg-base-100 shadow-md rounded-md p-6 relative">
        <form method="POST" action="posts.php">
            <h2 class="text-xl font-bold mb-4">Add Product</h2>

            <button type="button" class="btn btn-sm btn-circle btn-ghost absolute top-4 right-4"
                onclick="window.location.href='posts.php'">✕</button>

            <label class="label" for="title">Title</label>
            <input type="text" name="title" class="input input-bordered w-full" required />

            <label class="label" for="description">Description</label>
            <textarea name="description" class="textarea textarea-bordered w-full mb-2"
                required></textarea>

            <label class="label" for="price">Price</label>
            <input type="number" name="price" class="input input-bordered w-full mb-2" required />

            <label class="label" for="discountPercentage">Discount Percentage</label>
            <input type="number"name="discountPercentage"
                class="input input-bordered w-full mb-2" required />

            <label class="label" for="rating">Rating</label>
            <input type="number" name="rating" class="input input-bordered w-full mb-4" />

            <div class="flex justify-end gap-2">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="button" class="btn btn-outline" onclick="window.location.href='posts.php'">Cancel</button>
            </div>
        </form>
    </div>
</body>

</html>