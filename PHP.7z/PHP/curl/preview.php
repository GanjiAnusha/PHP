<?php
include("session.php");

// if (!isset($_SESSION['accessToken'])) {
//     header("Location: auth.php");
//     exit;
// }

$productId = $_GET['pid'];
$ch = curl_init("https://dummyjson.com/products/{$productId}");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$product = json_decode($response, true);
if (!$product) {
    echo "Product not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title><?= ($product['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
</head>
    <body>
        <div class="card w-96 bg-base-100 shadow-xl m-4">
            <figure><img src="<?= $product['thumbnail'] ?>" alt="Product Image" /></figure>
            <div class="card-body">
                <h2 class="card-title"><?= ($product['title']) ?></h2>
                <p><?= $product['description'] ?></p>
                <h2><b>Price: </b><del><?= $product['price'] ?></del></h2>
                <h2><b>Discount Percentage: </b><i><?= $product['discountPercentage'] ?>%</i></h2>
                <h2><b>Discounted Price: </b>
                    <?php
                    $discount = ($product['price'] * $product['discountPercentage']) / 100;
                    echo $product['price'] - $discount;
                    ?>
                </h2>
                <h2><b>Rating:</b>
                    <?php
                    $rating = round($product['rating']);
                    for ($i = 1; $i <= 5; $i++) {
                        echo $i <= $rating ? '<span class="text-yellow-400">&#9733;</span>' : '<span class="text-gray-400">&#9734;</span>';
                    }
                    ?>
                </h2>
                <h2><b>Reviews:</b></h2>
                <ul>
                    <?php foreach ($product['reviews'] as $review) { ?>
                        <li>
                            <strong><?= $review['reviewerName'] ?> (Rating: <?= $review['rating'] ?>)</strong>
                            <p><?= $review['comment'] ?></p>
                            <p><small>Reviewed on: <?= date('F j, Y', strtotime($review['date'])) ?></small></p>
                        </li>
                    <?php } ?>
                </ul>
                <div class="mt-4">
                    <h2><b>SKU:</b> <?= $product['sku'] ?></h2>
                    <h2><b>Stock Status:</b> <?= $product['availabilityStatus'] ?></h2>
                    <h2><b>Shipping:</b> <?= $product['shippingInformation'] ?></h2>
                    <h2><b>Warranty:</b> <?= $product['warrantyInformation'] ?></h2>
                    <h2><b>Return Policy:</b> <?= $product['returnPolicy'] ?></h2>
                </div>
                <!-- <div class="mt-4">
                    <img src="<? //$product['meta']['qrCode'] ?>" alt="Product QR Code" />
                </div> -->
            </div>
            <div class="button-container">
                <!-- <a href="<? //"product.php?pid={$product['id']}" ?>">
                            <button class="btn btn-primary">Submit</button>
                        </a>-->
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-primary" onClick="window.print()">Print</button>
                <a href="<?= "posts.php" ?>">
                    <button class="btn btn-primary">Home</button>
                </a>
            </div>
        </div>
    </body>
</html>