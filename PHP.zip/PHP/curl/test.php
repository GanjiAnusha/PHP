<?php
include("session.php");
$error = '';
$limit = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$skip = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username && $password) {
            $ch = curl_init('https://dummyjson.com/auth/login');
            $payload = json_encode(['username' => $username, 'password' => $password]);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_HTTPHEADER => ['Content-Type: application/json']
            ]);
            $response = curl_exec($ch);
            curl_close($ch);

            $data = json_decode($response, true);
            if (!empty($data['token'])) {
                $_SESSION['accessToken'] = $data['token'];
                $_SESSION['user'] = $data;
                header("Location: products.php");
                exit;
            } else {
                $error = "Invalid credentials. Please try again.";
            }
        } else {
            $error = "Please enter both username and password.";
        }
    }
}

// Fetch Products
$url = $search 
    ? "https://dummyjson.com/products/search?q=" . urlencode($search) . "&limit=$limit&skip=$skip"
    : "https://dummyjson.com/products?limit=$limit&skip=$skip";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$products = json_decode($response, true);

// Merge with session custom products
if (!empty($_SESSION['custom_products'])) {
    $apiProductsById = [];
    foreach ($products['products'] as $prod) {
        $apiProductsById[$prod['id']] = $prod;
    }
    foreach ($_SESSION['custom_products'] as $sessProd) {
        $apiProductsById[$sessProd['id']] = $sessProd;
    }
    $products['products'] = array_values($apiProductsById);
}

$total = $products['total'] ?? 0;
$totalPages = ceil($total / $limit);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="p-5">
    <form method="GET" class="flex gap-2 items-center mb-5">
        <input type="search" name="search" placeholder="Search products" value="<?= htmlspecialchars($search) ?>" class="input input-bordered w-full max-w-xs" />
        <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <div class="flex justify-between mb-5">
        <?php if (!isset($_SESSION['accessToken'])): ?>
            <button class="btn btn-primary" onclick="document.getElementById('loginModal').showModal()">Login</button>
        <?php else: ?>
            <div class="flex gap-2">
                <a href="add.php" class="btn btn-primary">Add Product</a>
                <a href="get_auth_user.php" class="btn btn-primary">User Info</a>
                <a href="logout.php" class="btn btn-primary">Logout</a>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error mb-5"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <?php if (!empty($products['products'])):
            $deleted = $_SESSION['deleted_products'] ?? [];

            foreach ($products['products'] as $product):
                if (in_array($product['id'], $deleted)) continue;
        ?>
            <div class="card bg-base-100 shadow-md">
                <figure><img src="<?= htmlspecialchars($product['thumbnail'] ?? 'default.jpg') ?>" alt="Product image" class="h-48 object-cover w-full" /></figure>
                <div class="card-body">
                    <h2 class="card-title"><?= htmlspecialchars($product['title']) ?></h2>
                    <p><?= htmlspecialchars($product['description']) ?></p>
                    <p><b>Price:</b> <del>$<?= number_format($product['price'], 2) ?></del></p>
                    <p><b>Discount:</b> <?= htmlspecialchars($product['discountPercentage']) ?>%</p>
                    <p><b>Discounted Price:</b> $<?= number_format($product['price'] * (1 - $product['discountPercentage'] / 100), 2) ?></p>
                    <p><b>Rating:</b>
                        <?php
                        $rating = round($product['rating']);
                        for ($i = 1; $i <= 5; $i++) {
                            echo $i <= $rating ? '<span class="text-yellow-400">&#9733;</span>' : '<span class="text-gray-400">&#9734;</span>';
                        }
                        ?>
                    </p>
                    <div class="card-actions justify-end">
                        <?php if (!isset($_SESSION['accessToken'])): ?>
                            <button class="btn btn-sm btn-primary" onclick="document.getElementById('loginModal').showModal()">More</button>
                        <?php else: ?>
                            <a href="preview.php?pid=<?= urlencode($product['id']) ?>" class="btn btn-sm btn-primary">More</a>
                            <a href="update.php?id=<?= urlencode($product['id']) ?>" class="btn btn-sm btn-warning">Update</a>
                            <a href="delete.php?id=<?= urlencode($product['id']) ?>" class="btn btn-sm btn-error">Delete</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; else: ?>
            <p>No products found.</p>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <div class="flex justify-center mt-10 space-x-2">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>" class="btn <?= $page == $i ? 'btn-active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>

    <!-- Login Modal -->
    <dialog id="loginModal" class="modal">
        <div class="modal-box">
            <form method="POST">
                <h2 class="font-bold text-lg mb-4">Login</h2>
                <button type="button" class="btn btn-sm btn-circle btn-ghost absolute right-2 top-4" onclick="document.getElementById('loginModal').close()">✕</button>

                <?php if ($error): ?>
                    <div class="alert alert-error p-2 text-sm"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <label class="label">Username</label>
                <input type="text" name="username" class="input input-bordered w-full" required>

                <label class="label">Password</label>
                <input type="password" name="password" class="input input-bordered w-full" required>

                <div class="modal-action">
                    <button type="submit" name="login" class="btn btn-primary">Login</button>
                    <button type="button" class="btn" onclick="document.getElementById('loginModal').close()">Cancel</button>
                </div>
            </form>
        </div>
    </dialog>

    <?php if ($error): ?>
        <script>document.getElementById('loginModal').showModal();</script>
    <?php endif; ?>
</body>
</html>
