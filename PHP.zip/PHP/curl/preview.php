<?php
include("session.php");

if (!isset($_SESSION['accessToken'])) {
   // header("Location: auth.php");
    exit;
}

$productId = $_GET['pid'];
$ch = curl_init("https://dummyjson.com/products/{$productId}");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$product = json_decode($response, true);
if (!$product) {
    echo "Product not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= ($product['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
    <body class="min-h-screen bg-gray-100 flex items-center justify-center">
        <div class="card w-96 bg-base-100 m-4">
            <img src="<?= isset($product['thumbnail']) ? $product['thumbnail'] : 'default.jpg' ?>" alt="Product Image" width="250px"/>
            <div class="card-body">
                <h2 class="card-title"><?= isset($product['title'])?$product['title'] : 'Not updated yet' ?></h2>
                <p><?= isset($product['description'])?$product['description']:'Not updated yet' ?></p>
                <h2><b>Price: </b><del><?= isset($product['price'])?$product['price']:'Not updated yet' ?></del></h2>
                <h2><b>Discount Percentage: </b><i><?= isset($product['discountPercentage'])?$product['discountPercentage']:'Not updated yet' ?>%</i></h2>
                <h2><b>Discounted Price: </b>
                    <?php
                    $discount = isset($product['price'], $product['discountPercentage']) 
                    ? ($product['price'] * $product['discountPercentage']) / 100 
                    : 'Not updated yet';
                    echo isset($product['price']) ? ($product['price'] - $discount) : null;
                    ?>
                </h2>
                <h2><b>Rating:</b>
                    <?php
                    if (isset($product['rating'])) {
                        $rating = round($product['rating']);
                    } else {
                        $rating = 0;
                    }

                    for ($i = 1; $i <= 5; $i++) {
                        echo $i <= $rating ? '<span class="text-yellow-400">&#9733;</span>' : '<span class="text-gray-400">&#9734;</span>';
                    }
                    ?>
                </h2>
                <h2><b>Reviews:</b></h2>
               
                <?php if (!empty($product['reviews']) && is_array($product['reviews'])): ?>
                <ul>
                    <?php foreach ($product['reviews'] as $review): ?>
                        <li>
                            <strong><?= $review['reviewerName'] ?> (Rating: <?= (int)$review['rating'] ?>)</strong>
                            <p><?= nl2br($review['comment']) ?></p>
                            <p><small>Reviewed on: <?= date('F j, Y', strtotime($review['date'])) ?></small></p>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                    <p>No reviews yet.</p>
                <?php endif; ?>

                <div class="mt-4">
                    <h2><b>SKU:</b> <?= isset($product['sku'])?$product['sku']:'Not updated yet' ?></h2>
                    <h2><b>Stock Status:</b> <?= isset($product['availabilityStatus'])?$product['availabilityStatus']:'Not updated yet' ?></h2>
                    <h2><b>Shipping:</b> <?= isset($product['shippingInformation'])?$product['shippingInformation']:'Not updated yet' ?></h2>
                    <h2><b>Warranty:</b> <?= isset($product['warrantyInformation'])?$product['warrantyInformation']:'Not updated yet'; ?></h2>
                    <h2><b>Return Policy:</b> <?=  isset($product['warrantyInformation'])?$product['returnPolicy']:'Not updated yet' ?></h2>
                </div>
            </div>
            <div class="button-container">
                <button class="btn btn-primary ml-24" onClick="window.print()">Print</button>
                <a href="<?= "posts.php" ?>">
                    <button class="btn btn-primary ml-2">Home</button>
                </a>
            </div>
        </div>
    </body>
</html>
