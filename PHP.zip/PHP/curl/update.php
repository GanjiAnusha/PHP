<?php
include("session.php");

$id = $_GET['id'] ?? null;
$error = '';
$product = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $updatedProduct = [
        'title' => $_POST['title'],
        'price' => (float) $_POST['price'],
        'discountPercentage' => (float) $_POST['discountPercentage'],
        'description' => $_POST['description'],
        'rating' => (float) $_POST['rating']
    ];

    $foundInSession = false;

    // Update product in session if exists
    if (!empty($_SESSION['custom_products'])) {
        foreach ($_SESSION['custom_products'] as &$prod) {
            if ($prod['id'] == $id) {
                $prod = array_merge($prod, $updatedProduct);
                $foundInSession = true;
                break;
            }
        }
        unset($prod);
    }

    if ($foundInSession) {
        // Redirect after session update
        header("Location: posts.php");
        exit;
    }

    // Otherwise, update via API
    $ch = curl_init("https://dummyjson.com/products/$id");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_POSTFIELDS => json_encode($updatedProduct),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error = "cURL Error: " . curl_error($ch);
    }
    curl_close($ch);

    $product = json_decode($response, true);

    if (!empty($product['id'])) {
        if (!isset($_SESSION['custom_products'])) {
            $_SESSION['custom_products'] = [];
        }
        $updated = false;
        foreach ($_SESSION['custom_products'] as $key => $prod) {
            if ($prod['id'] == $id) {
                $_SESSION['custom_products'][$key] = $product;
                $updated = true;
                break;
            }
        }
        if (!$updated) {
            // Add if not exists in session (override API product)
            $_SESSION['custom_products'][] = $product;
        }

        header("Location: posts.php");
        exit;
    } else {
        $error = "Failed to update product.";
    }

} else {
    // On GET: fetch product either from session or API
    $product = null;
    if (!empty($_SESSION['custom_products'])) {
        foreach ($_SESSION['custom_products'] as $p) {
            if ($p['id'] == $id) {
                $product = $p;
                break;
            }
        }
    }

    if (!$product) {
        $ch = curl_init("https://dummyjson.com/products/$id");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        $product = json_decode($response, true);
    }

    if (!$product) {
        die("Product not found.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Update Product</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
    <div class="card bg-base-100 shadow-md rounded-md p-6 w-full max-w-lg">
        <form method="POST">
            <h2 class="text-2xl font-bold mb-4">Update Product</h2>

            <?php if ($error): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>

            <label class="label" for="title">Title</label>
            <input type="text" name="title" value="<?= $product['title'] ?>" class="input input-bordered w-full mb-2"
                required>

            <label class="label" for="description">Description</label>
            <textarea name="description" class="textarea textarea-bordered w-full mb-2"
                required><?= $product['description'] ?></textarea>

            <label class="label" for="price">Price</label>
            <input type="number" name="price" value="<?= $product['price'] ?>" class="input input-bordered w-full mb-2"
                required>

            <label class="label" for="discountPercentage">Discount Percentage</label>
            <input type="number" name="discountPercentage" value="<?= $product['discountPercentage'] ?>"
                class="input input-bordered w-full mb-2" required>

            <label class="label" for="rating">Rating</label>
            <input type="number" name="rating" value="<?= $product['rating'] ?>"
                class="input input-bordered w-full mb-4">

            <div class="flex justify-end gap-2">
                <button type="submit" name="update" class="btn btn-primary">Update</button>
                <a href="posts.php" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>
</body>

</html>