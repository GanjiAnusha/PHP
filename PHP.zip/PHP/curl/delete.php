<?php
session_start();
$id = intval($_GET['id']);

// Custom product removal
if (isset($_SESSION['products'])) {
    foreach ($_SESSION['products'] as $i => $product) {
        if ($product['id'] == $id) {
            unset($_SESSION['products'][$i]);
            $_SESSION['products'] = array_values($_SESSION['products']);
            header("Location: posts.php");
            exit;
        }
    }
}

if (!isset($_SESSION['deleted_products'])) {
    $_SESSION['deleted_products'] = [];
}
$_SESSION['deleted_products'][] = $id;

header("Location: posts.php");
exit;
