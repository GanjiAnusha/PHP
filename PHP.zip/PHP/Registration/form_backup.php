<?php
include("session.php");

if (!isset($_SESSION['guest_id'])) {
    $_SESSION['guest_id'] = uniqid();
}

$productId = $_GET['pid'];
$ch = curl_init("https://dummyjson.com/products/{$productId}");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$product = json_decode($response, true);

if (!$product) {
    echo "Product not found.";
    exit;
}
?>

<html lang="en">

<head>
    <title>Product Details - <?= ($product['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="card w-96 bg-base-100 shadow-xl m-4">
        <!-- <form action="product.php?pid=<?// $product['id'] ?>" method="POST">-->
            <?php //echo($_SERVER["SELF"]); ?>
         <form action="display.php" method="POST">

        <div class="card-body">
            <h2 class="card-title"><?= ($product['title']) ?></h2>
            <div>
                <img src="<?= $product['thumbnail'] ?>" alt="Product Image" class="w-full mb-4" />
            </div>
            <fieldset class="fieldset bg-base-200 border-base-300 rounded-box w-xs border p-4">
                <legend class="fieldset-legend">Product Description</legend>

                <label class="label">Title</label>
                <input type="text" name="title" value="<?= ($product['title']) ?>" class="input" />

                <label class="label">Description</label>
                <textarea class="textarea h-24" name="description"><?= $product['description'] ?></textarea>

                <label class="label">Price</label>
                <input type="number" name="price" value="<?= $product['price'] ?>" class="input" />

                <label class="label">Discount Percentage:</label>
                <input type="number" name="discountPercentage" value="<?= $product['discountPercentage'] ?>"
                    class="input" />

                <label class="label">Rating:</label>
                <input type="number" name="rating" value="<?= $product['rating'] ?>" class="input" />

                <label class="label">Reviews</label>
                <textarea name="reviews" class="textarea h-24" name="reviews" readonly>
                                <?php foreach ($product['reviews'] as $review) {
                                    echo "{$review['reviewerName']}(Rating:{$review['rating']}):{$review['comment']}-" . date('F j, Y', strtotime($review['date'])) . "\n";
                                } ?>
                            </textarea>

                <label class="label">SKU:</label>
                <input type="text" name="sku" value="<?= ($product['sku']) ?>" class="input" />

                <label class="label">Stock Status:</label>
                <input type="text" name="stockStatus" value="<?= ($product['availabilityStatus']) ?>" class="input" />

                <label class="label">Shipping Information:</label>
                <input type="text" name="shippingInfo" value="<?= ($product['shippingInformation']) ?>" class="input" />

                <label for="warrantyInfo" class="label">Warranty Information:</label>
                <input type="text" name="warrantyInfo" value="<?= ($product['warrantyInformation']) ?>" class="input" />

                <label class="label">Return Policy:</label>
                <input type="text" name="returnPolicy" value="<?= ($product['returnPolicy']) ?>" class="input" />

                <label for="qrCode" class="label">QR Code:</label>
                <input type="text" name="qrCode" value="<?= $product['meta']['qrCode'] ?>" class="input" />

            </fieldset>
                <div class="button-container">
                    <a href="<?= "product.php?pid={$product['id']}" ?>">
                        <button class="btn btn-primary">Submit</button>
                    </a>    
                    <!-- <a href="<?//"preview.php?pid={$product['id']}" ?>">
                        <button class="btn btn-primary">Preview</button>
                    </a>     -->
                    <button class="btn btn-primary" onClick="window.print()">Print</button>
                </div>
            </div>
        </div>
    </div>
    </form>
    </div>
</body>

</html>