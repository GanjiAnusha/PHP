<?php
include("session.php");

$error = '';
$limit = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$skip = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username && $password) {
            $ch = curl_init('https://dummyjson.com/auth/login');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode(['username' => $username, 'password' => $password]),
                CURLOPT_HTTPHEADER => ['Content-Type: application/json']
            ]);
            $response = curl_exec($ch);
            curl_close($ch);

            $data = json_decode($response, true);
            if (!empty($data['accessToken'])) {
                $_SESSION['accessToken'] = $data['accessToken'];
                $_SESSION['user'] = $data;
                header("Location: posts.php");
                exit;
            } else {
                $error = "Invalid credentials.";
            }
        } else {
            $error = "Please fill in all fields.";
        }
    } elseif (isset($_POST['title'])) {
        $newProduct = [
            'title' => $_POST['title'],
            'price' => $_POST['price'],
            'discountPercentage' => $_POST['discountPercentage'],
            'description' => $_POST['description'],
            'rating' => $_POST['rating']
        ];
        $ch = curl_init('https://dummyjson.com/products/add');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($newProduct),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json']
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $addedProduct = json_decode($response, true);
        $_SESSION['custom_products'][] = $addedProduct;
    }
}

// Fetch products from API
$url = $search
    ? "https://dummyjson.com/products/search?q=" . urlencode($search) . "&limit=$limit&skip=$skip"
    : "https://dummyjson.com/products?limit=$limit&skip=$skip";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$products = json_decode($response, true);

// Merge session products
if (!empty($_SESSION['custom_products'])) {
    $existing = [];
    foreach ($products['products'] as $prod) {
        $existing[$prod['id']] = $prod;
    }
    foreach ($_SESSION['custom_products'] as $prod) {
        $existing[$prod['id']] = $prod;
    }
    $products['products'] = array_values($existing);
}

$total = $products['total'] ?? count($products['products']);
$totalPages = ceil($total / $limit);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        .product-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: flex-start;
        }

        .product-card {
            width: 300px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="card-actions justify-end">
        <form method="GET" class="flex gap-2 items-center mb-5 mt-5 justify-center">
        <input type="search" name="search" placeholder="Search products" value="<?= htmlspecialchars($search) ?>" class="input input-bordered w-full max-w-xs" />
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
        <?php if (!isset($_SESSION['accessToken'])): ?>
            <button class="btn btn-primary mt-5 mr-5"
                onclick="document.getElementById('loginModal').showModal()">Login</button>
        <?php else: ?>
            <a href="add.php" class="btn btn-primary mt-5" aria-label="Add product">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-fill"
                    viewBox="0 0 16 16">
                    <path
                        d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                </svg>
                Add product
            </a>

            <a href="get_auth_user.php" class="btn btn-primary mt-5">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi-person-fill"
                    viewBox="0 0 16 16">
                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                </svg>
                User Info
            </a>

            <a href="logout.php" class="btn btn-primary mt-5 mr-5 bi bi-box-arrow-right">
                <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                    <path
                        d="M9 12a.5.5 0 0 1-.5-.5V9H3a.5.5 0 0 1-.5-.5V7a.5.5 0 0 1 .5-.5h5.5V4.5a.5.5 0 0 1 .854-.354l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.854-.354V9H3a.5.5 0 0 1-.5-.5V7a.5.5 0 0 1 .5-.5h5.5V4.5a.5.5 0 0 1 .854-.354l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.854-.354V9H3a.5.5 0 0 1-.5-.5z" />
                </svg>
                Logout
            </a>
        <?php endif; ?>
    </div>
    
    <!-- Login Modal -->
    <dialog id="loginModal" class="modal">
        <div class="modal-box">
            <form method="POST">
                <h2 class="font-bold text-lg mb-4">Login</h2>
                <button type="button" class="btn btn-sm btn-circle btn-ghost absolute right-2 top-4"
                    onclick="document.getElementById('loginModal').close()">✕</button>

                <?php if ($error): ?>
                    <div class="alert alert-error p-2 text-sm"><?= ($error) ?></div>
                <?php endif; ?>

                <label class="label">Username</label>
                <input type="text" name="username" class="input input-bordered w-full" required>

                <label class="label">Password</label>
                <input type="password" name="password" class="input input-bordered w-full" required>

                <div class="modal-action">
                    <button type="submit" name="login" class="btn btn-primary">Login</button>
                    <button type="button" class="btn"
                        onclick="document.getElementById('loginModal').close()">Cancel</button>
                </div>
            </form>
        </div>
    </dialog>

    <div class="product-container">
        <?php if (!empty($products['products'])):
            $deleted = $_SESSION['deleted_products'] ?? [];

            foreach ($products['products'] as $product):
                if (in_array($product['id'], $deleted))
                    continue;
                ?>
                <div class="product-card card bg-base-100">
                    <img src="<?= ($product['thumbnail'] ?? 'default.jpg') ?>" alt="Product Image" />
                    <div class="card-body">
                        <p><?= ($product['id']) ?></p>
                        <h2 class="card-title"><?= ($product['title']) ?></h2>
                        <p><?= ($product['description']) ?></p>
                        <h2><b>Price:</b> <del>$<?= number_format($product['price'], 2) ?></del></h2>
                        <h2><b>Discount:</b> <?= ($product['discountPercentage']) ?>%</h2>
                        <h2><b>Discounted Price:</b>
                            $<?= number_format($product['price'] * (1 - $product['discountPercentage'] / 100), 2) ?></h2>
                        <h2><b>Rating:</b>
                            <?php
                            $rating = round($product['rating']);
                            for ($i = 1; $i <= 5; $i++) {
                                echo $i <= $rating ? '<span class="text-yellow-400">&#9733;</span>' : '<span class="text-gray-400">&#9734;</span>';
                            }
                            ?>
                        </h2>
                        <div class="card-actions">
                            <?php if (!isset($_SESSION['accessToken'])): ?>
                                <button class="btn btn-primary" onclick="document.getElementById('loginModal').showModal()">More...</button>
                            <?php else: ?>
                                <a href="preview.php?pid=<?= urlencode($product['id']) ?>">
                                    <button class="btn btn-primary">More...</button>
                                </a>
                            <?php endif; ?>
                            <?php if (!isset($_SESSION['accessToken'])): ?>
                                <button class="btn btn-primary" onclick="document.getElementById('loginModal').showModal()">Update</button>
                            <?php else: ?>
                                <a href="update.php?id=<?= urlencode($product['id']) ?>">
                                <button class="btn btn-primary">Update</button>
                            </a>
                            <?php endif; ?>
                            <?php if (!isset($_SESSION['accessToken'])): ?>
                                <button class="btn btn-primary" onclick="document.getElementById('loginModal').showModal()">Delete</button>
                                <?php else: ?>
                                    <a href="delete.php?id=<?= urlencode($product['id']) ?>">
                                        <button class="btn btn-primary">Delete</button>
                                    </a>
                                    <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; else: ?>
            <p>No products found.</p>
        <?php endif; ?>
    </div>
    <?php if ($error): ?>
        <script>document.getElementById('loginModal').showModal();</script>
    <?php endif; ?>
    <!-- Pagination -->
    <div class="flex justify-center mt-10 space-x-2">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>" class="btn <?= $page == $i ? 'btn-active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>
</body>
</html>