<?php
session_start();
if (isset($_SESSION['accessToken'])) {
    header("Location: posts.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username && $password) {
        $ch = curl_init('https://dummyjson.com/auth/login');
        $payload = json_encode([
            'username' => $username,
            'password' => $password
        ]);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);

        if (isset($data['accessToken'])) {
            $_SESSION['accessToken'] = $data['accessToken'];
            $_SESSION['user'] = $data; 
            header("Location: posts.php");
            exit;
        } else {
            $error = "Invalid credentials. Please try again.";
        }
    } else {
        $error = "Please enter both username and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
    <div class="card w-96 bg-base-100 shadow-xl">
        <div class="card-body">
            <h2 class="card-title">Login to Your Account</h2>
            <?php if (!empty($error)): ?>
                <div class="alert alert-error p-2 text-sm">
                    <?= $error ?>
                </div>
            <?php endif; ?>
            <form method="POST" class="space-y-4">
                <div>
                    <label class="label">Username</label>
                    <input type="text" name="username" class="input input-bordered w-full" required>
                </div>
                <div>
                    <label class="label">Password</label>
                    <input type="password" name="password" class="input input-bordered w-full" required>
                </div>
                <div class="card-actions">
                    <button type="submit" class="btn btn-primary w-full">Login</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

