<?php
session_name("sess");
session_start();
// echo session_id();
// if (isset($_SESSION['email'])) 
// {
//     echo "session is set and the session id is:  ".session_id();
//     header("Content-Type: dashboard.php");
//     exit();
// }
// else{
//       echo "You are not logged in. Please log in to continue.";
// }