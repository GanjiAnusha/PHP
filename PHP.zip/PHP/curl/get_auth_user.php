<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: auth.php");
    exit;
}
$user = $_SESSION['user'];
$userId = $_SESSION['user']['id'];
$ch = curl_init("https://dummyjson.com/users/$userId");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$user = json_decode($response, true);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>User Info</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="min-h-screen bg-gray-100 flex items-center justify-center">
    <div class="card w-96 bg-base-100 shadow-xl">
        <div class="card-body">
            <h2 class="card-title">User Info <button type="button"
                    class="btn btn-sm btn-circle btn-ghost absolute top-4 right-4"
                    onclick="window.location.href='posts.php'">✕</button></h2>
            <i><strong>Full Name:</strong> <?= $user['firstName'] . ' ' . $user['lastName'] ?></i>
            <i><strong>Username:</strong> <?= $user['username'] ?></i>
            <i><strong>Email:</strong> <?= $user['email'] ?></i>
            <i><strong>Gender:</strong> <?= $user['gender'] ?></i>
            <i><strong>ID:</strong> <?= $user['id'] ?></i>
            <i><strong>phone:</strong> <?= $user['phone'] ?></i>
            <i><strong>Age:</strong> <?= $user['age'] ?></i>
            <i><strong>Gender:</strong> <?= $user['gender'] ?></i>
            <i><strong>Birthdate:</strong> <?= $user['birthDate'] ?></i>
            <i><strong>Eye Color:</strong> <?= $user['eyeColor'] ?></i>
            <i><strong>Hair:</strong> <?= $user['hair']['color'] ?>, <?= $user['hair']['type'] ?></i>

            <h2 class="text-xl font-semibold mt-2">Address</h2>
            <i><?= $user['address']['address'] ?>, <?= $user['address']['city'] ?>, <?= $user['address']['state'] ?>
                <?= $user['address']['postalCode'] ?></p>
                <i>Country: <?= $user['address']['country'] ?></i>

                <h2 class="text-xl font-semibold mt-2">Company</h2>
                <p><strong>Company:</strong> <?= $user['company']['name'] ?></p>
                <p><strong>Department:</strong> <?= $user['company']['department'] ?></p>
                <p><strong>Title:</strong> <?= $user['company']['title'] ?></p>

                <h2 class="text-xl font-semibold mt-2">Bank & Crypto</h2>
                <p><strong>Bank:</strong> <?= $user['bank']['cardType'] ?> ending in
                    <?= substr($user['bank']['cardNumber'], -4) ?></p>
                <p><strong>Crypto Wallet:</strong> <?= $user['crypto']['wallet'] ?> (<?= $user['crypto']['coin'] ?>)</p>

                <h2 class="text-xl font-semibold mt-2">Other</h2>
                <p><strong>University:</strong> <?= $user['university'] ?></p>
                <p><strong>IP Address:</strong> <?= $user['ip'] ?></p>
                <p><strong>MAC Address:</strong> <?= $user['macAddress'] ?></p>
                <p><strong>SSN:</strong> <?= $user['ssn'] ?></p>

                <div class="mt-2">
                    <a href="posts.php" class="btn btn-primary ml-24">Back to Products</a>
                </div>
        </div>
    </div>
</body>

</html>