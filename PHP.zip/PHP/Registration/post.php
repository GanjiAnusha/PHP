<?php
// include("session.php");
// if (!isset($_SESSION['accessToken'])) {
//     header("Location: auth.php");
// }

$curl = curl_init('https://dummyjson.com/products');

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://dummyjson.com/products/add',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{
    "title": $_POST["title"] ,
    "price": $_POST["price"],
    "discountPercentage": $_POST["discountPercentage"],
    "stock": $_POST["stock"],
    "description": $_POST["description"]
    "brand": $_POST["brand"],
    "category": $_POST["category"],
}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);
$products = json_decode($response, true) ?? [];
curl_close($curl);
echo $response;


if (isset($newProduct)) {
    $products['products'][] = $newProduct;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Posts</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        .product-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: flex-start;
        }

        .product-card {
            width: 300px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <dialog id="productModal" class="modal">
        <div class="modal-box">
            <form action="display.php" method="POST">
                
                <h2 class="font-bold text-lg mb-4">Add Product</h2>

                <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-4">✕</button>

                <label class="label">Title</label>
                <input type="text" name="title" class="input input-bordered w-full mb-2" />

                <label class="label">Description</label>
                <textarea class="textarea textarea-bordered w-full mb-2" name="description"></textarea>

                <label class="label">Price</label>
                <input type="number" class="input input-bordered w-full mb-2" name="price" />

                <label class="label">Discount Percentage</label>
                <input type="number" name="discountPercentage" class="input input-bordered w-full mb-2" />

                <label class="label">Rating</label>
                <input type="number" name="rating" class="input input-bordered w-full mb-2" />

                <!-- <label class="label">Reviews</label>
                <textarea name="reviews" class="textarea textarea-bordered w-full mb-2"></textarea>

                <label class="label">SKU</label>
                <input type="text" name="sku" class="input input-bordered w-full mb-2" />

                <label class="label">Stock Status</label>
                <input type="text" name="stockStatus" class="input input-bordered w-full mb-2" />

                <label class="label">Shipping Information</label>
                <input type="text" name="shippingInfo" class="input input-bordered w-full mb-2" />

                <label class="label">Warranty Information</label>
                <input type="text" name="warrantyInfo" class="input input-bordered w-full mb-2" />

                <label class="label">Return Policy</label>
                <input type="text" name="returnPolicy" class="input input-bordered w-full mb-2" /> -->

                <!-- <label class="label">QR Code</label>
                <input type="text" name="qrCode" class="input input-bordered w-full mb-4" /> -->

                <div class="modal-action">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="button" class="btn"
                        onclick="document.getElementById('productModal').close()">Cancel</button>
                </div>
            </form>
        </div>
    </dialog>
    <div class="card-actions justify-end">
    <button class="btn btn-primary" onclick="document.getElementById('productModal').showModal()">Add product</button></div>
    <div class="product-container">
        <?php
        if (count($products) > 0) {
            foreach ($products['products'] as $product) {
                ?>
                <div class="product-card card bg-base-100">
                    <img src="<?= $product['thumbnail'] ?>" alt="Product Image" />
                    <div class="card-body">
                        <h2><b>Price: </b><del><?= $product['price'] ?></del></h2>
                        <h2><b>Discount Percentage: </b><i><?= $product['discountPercentage'] ?>%</i></h2>
                        <h2><b>Discounted price:</b>
                            <?php
                            $discount = ($product['price'] * $product['discountPercentage']) / 100;
                            echo $product['price'] - $discount;
                            ?>
                        </h2>

                        <?php
                        $rating = round($product['rating']);
                        ?>

                        <h2><b>Rating: </b>
                            <?php
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= $rating) {
                                    echo '<span class="text-yellow-400">&#9733;</span>';
                                } else {
                                    echo '<span class="text-gray-400">&#9734;</span>';
                                }
                            }
                            ?>
                        </h2>
                        <h2 class="card-title"><?= $product['title'] ?></h2>
                        <p><?= $product['description'] ?></p>
                        <div class="card-actions justify-end">
                            <a href="<?= "preview.php?pid={$product['id']}" ?>">
                                <button class="btn btn-primary">View More</button>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "No posts found.";
        }
        ?>

    </div>
</body>

</html>