<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newProduct = [
        'title' => $_POST['title'],
        'price' => (float)$_POST['price'],
        'discountPercentage' => (float)$_POST['discountPercentage'],
        'description' => $_POST['description'],
        'rating' => (float)$_POST['rating']
    ];

    $ch = curl_init('https://dummyjson.com/products/add');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($newProduct));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $apiResponse = curl_exec($ch);
    curl_close($ch);

    $addedProduct = json_decode($apiResponse, true);
    $addedProduct['thumbnail'] = 'https://via.placeholder.com/300?text=New+Product';
    $_SESSION['custom_products'][] = $addedProduct;
}

$ch = curl_init('https://dummyjson.com/products');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$products = json_decode($response, true);

if (!empty($_SESSION['custom_products'])) {
    $products['products'] = array_merge($products['products'], $_SESSION['custom_products']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        .product-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: flex-start;
        }
        .product-card {
            width: 300px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<div class="card-actions justify-end">
    <button class="btn btn-primary" onclick="document.getElementById('productModal').showModal()">Add product</button>
</div>


<dialog id="productModal" class="modal">
    <div class="modal-box">
        <form method="POST">
            <h2 class="font-bold text-lg mb-4">Add Product</h2>
            <button type="button" class="btn btn-sm btn-circle btn-ghost absolute right-2 top-4"
                    onclick="document.getElementById('productModal').close()">✕</button>

            <label class="label">Title</label>
            <input type="text" name="title" required class="input input-bordered w-full mb-2" />

            <label class="label">Description</label>
            <textarea class="textarea textarea-bordered w-full mb-2" name="description" required></textarea>

            <label class="label">Price</label>
            <input type="number" name="price" step="0.01" required class="input input-bordered w-full mb-2" />

            <label class="label">Discount Percentage</label>
            <input type="number" name="discountPercentage" step="0.01" required class="input input-bordered w-full mb-2" />

            <label class="label">Rating</label>
            <input type="number" name="rating" step="0.1" max="5" required class="input input-bordered w-full mb-2" />

            <div class="modal-action">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="button" class="btn" onclick="document.getElementById('productModal').close()">Cancel</button>
            </div>
        </form>
    </div>
</dialog>

<div class="product-container p-4">
    <?php
    if (!empty($products['products'])) {
        foreach ($products['products'] as $product) {
            ?>
            <div class="product-card card bg-base-100">
                <img src="<?= htmlspecialchars($product['thumbnail']) ?>" alt="Product Image" />
                <div class="card-body">
                    <h2 class="card-title"><?= htmlspecialchars($product['title']) ?></h2>
                    <p><?= htmlspecialchars($product['description']) ?></p>
                    <h2><b>Price:</b> <del>$<?= $product['price'] ?></del></h2>
                    <h2><b>Discount:</b> <?= $product['discountPercentage'] ?>%</h2>
                    <h2><b>Discounted Price:</b>
                        $<?= number_format($product['price'] - ($product['price'] * $product['discountPercentage'] / 100), 2) ?>
                    </h2>
                    <h2><b>Rating:</b>
                        <?php
                        $rating = round($product['rating']);
                        for ($i = 1; $i <= 5; $i++) {
                            echo $i <= $rating
                                ? '<span class="text-yellow-400">&#9733;</span>'
                                : '<span class="text-gray-400">&#9734;</span>';
                        }
                        ?>
                    </h2>
                        <div class="card-actions justify-end">
                            <a href="<?= "preview.php?pid={$product['id']}" ?>">
                                <button class="btn btn-primary">View More</button>
                            </a>
                        </div>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<p>No products found.</p>";
    }
    ?>
</div>

</body>
</html>
