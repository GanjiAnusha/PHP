<?php
include("session.php");
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username && $password) {
        $ch = curl_init('https://dummyjson.com/auth/login');
        $payload = json_encode([
            'username' => $username,
            'password' => $password
        ]);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);

        if (isset($data['accessToken'])) {
            $_SESSION['accessToken'] = $data['accessToken'];
            $_SESSION['user'] = $data;
            header("Location: posts.php");
            exit;
        } else {
            $error = "Invalid credentials. Please try again.";
        }
    } else {
        $error = "Please enter both username and password.";
    }
} else {
    header("Location: posts.php");
}

?>